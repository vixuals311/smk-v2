#!/bin/bash
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then python3 install.py "$@"; else
  echo "Python 3 was not found. Copy the files in 'fuses' to ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Fuses/SMK2 and 'macros' to .../Fusion/Macros/SMK2"; fi
read -n 1 -s -r -p "Press any key to close"
