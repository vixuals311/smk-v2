@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul && (py -3 install.py %* & goto :done)
where python >nul 2>nul && (python install.py %* & goto :done)
echo Python 3 was not found. Install it from python.org, or copy the files in "fuses" to %%APPDATA%%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Fuses\SMK2
echo and the files in "macros" to ...\Fusion\Macros\SMK2
:done
pause
